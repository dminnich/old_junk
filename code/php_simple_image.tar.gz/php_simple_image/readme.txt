This is a simple PHP Random Image script.
-----------------------------------------
Displays a random image out of a text file full of links to images, or a
random image out of a directory full of images.

Features:
-------------
-Very small.  The entire script is one file.
-Text file based.  MySQL not needed.  
-Very easy to change. this script uses very straightforward syntax and has
lots of comments.  If you have ever messed with PHP you should be able to
adapt it to fit your needs.
-CSS customizable.  
-Easy to integrate into your current page.  
-completely free.  no links back to my page.  do whatever you like with this
script, i care not.

What this script doesn't do:
-------------------------------
-Allow you to add/edit/delete images from a web based manager.  
-No complicated randomizer / pseudo-generator is used in order to get "random"
results. 
-Does not output full page valid XHTML and CSS.  This is
intentional, so you can easily include the images in your current pages.
-Click tracking.  It does not count how many times an image is clicked.
-Scaling or format conversion.  This script displays the image as it is, with
no processing. 

Who this script is for:
----------------------------
-Me!
-People who want a small random image script that is easy to integrate into
their current site.  
-People who do not have access to a mysql server.
-For people new to PHP (like me).  This is a good script to look at and learn
from and adapt to your needs.

Installation
--------------
1) Update the source variable in image.php. 
   Choose either DIR or FILE.
If using FILE:
1) Update the imagesfile variable in image.php.
   -- This is only necessary if you plan on using a different file from
images.txt.  Or if you plan on putting images.txt in a folder other than the
directory this script is in.  If you do wish to change it use a path and
filename relative to where this script is.-- 
2) Add some links (ie:
http://www.google.com/intl/en/images/logo.gif) to images.txt.  Each link
should be separated by a new line.  
3) Upload image.php and images.txt to your webhost.
4) Make sure images.txt is world readable.  CHMOD it at least 444.
5) Test the script by going to yoursite/image.php. 
6) Include the images on your main pages.  Do <? include ("image.php"); ?> 
Wherever you want the images to appear.  This assumes that image.php is in the
same folder as your main page.  

If using DIR:
1) Update the imagesdir variable in image.php.  It should be the directory
where you have your random images.  It should be a full path or a path
relative to where this script is.  
2) Upload image.php to your webhost.  
3) Create the imagesdir from above on your server.  
4) Upload your random images into this folder. 
5) Make sure your imagesdir and all the images inside of it are CHMODed at
least 555.
6) Test the script by going to yoursite/image.php. 
7) Include the images on your main pages.  Do <? include ("image.php"); ?>
Wherever you want the images to appear.  This assumes that image.php is in the
same folder as your main page.  

Customization
--------------
Create a img.random CSS definition in the file that includes image.php.  This
will allow you to change the border and other things about the image.  

Change the starting HTML tags and closing HTML tags in image.php to make hard
coded changes to how the image appears.  


Notes
-------
-If you have any problems make sure that images.txt is world readable (chmoded
444), make sure the imagesfile variable points to a valid file, and make sure
that images.txt uses unix line breaks (windows may or may not work). Also make
sure that imagesdir and all images inside of it are chmoded at least 555 and
that the imagesdir variable is pointing to the proper directory. 
-Props to: 
   virtuallandmedia.com <-- I got my sample alphabet images from here.
   bigbold.com <-- I got my directory to array script snippet from here.  
-This script has not been thoroughly tested.  And has not been tested at all
under Windows.
-This is the only version of this script. I consider it a done project. 
-I guarantee nothing about this script. I am not offering any support for it,
so please do not contact me regarding it.

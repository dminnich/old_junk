<?
//This script can either get a random image out of a text file full of links to
//images, or it can choose a random image out of a directory full of images.
//To use the text file choose FILE below.  To use the directory choose DIR
//below. Make sure one is enabled and one is commented out (has // in front of
//it).  File is used by default.  
$source = 'FILE';
//$source = 'DIR'; 

//Relative path to and the filename of the file that contains the links to your
//random images. Each link should be separated by a NEW LINE.  The default is
//to use the file images.txt that is located in the same directory as this
//file.
$imagesfile = "images.txt";
//Relative path to the directory that contains all of your random images.  The
//default is to use the folder "images" that is located in the same directory
//as this script. NO trailing slash.   
$imagesdir = "images";
//You should not have to edit anything after this line.



//If using a file then ....
if ($source=='FILE') {


//Copy links from the text file into an array.  Don't display an error if the
//text file can not be opened.  This is to avoid ugliness in case you already
//have this PHP file included on your front page and something goes crazy.
if ($array = @file("$imagesfile")) {
//If the file was opened and the array was built successfully define the image
//variable.  The image variable gets a random value from the array. Here is
//how:  RAND(om) starts its result set at 0 (lowest possible value) and ends at
//the highest number in the array by COUNT(ing) the results and subtracting 1.
   $image = rand(0, count($array)-1);
//Echo the starting HTML tags for the image. Add a img.random CSS definition to
//the file that includes this one to customize how the image looks.
   echo "<img class=\"random\" src=\"";
//Echo a random image from the array.
   echo $array[$image];
//Echo the closing HTML tags for the image.
   echo "\" alt=\"random image\" />";
//If images file can not be found or opened say so.
}
else{
   echo ("<p>Images file not found or can not be opened.</p>");
}
}


//Else If using a directory....
elseif ($source=="DIR") {


//Function to read directory contents into an array.  Taken from
//http://www.bigbold.com/snippets/posts/show/155
function directoryToArray($directory, $recursive) {
	$array_items = array();
	if ($handle = @opendir($directory)) {
		while (false !== ($file = readdir($handle))) {
			if ($file != "." && $file != "..") {
				if (is_dir($directory. "/" . $file)) {
					if($recursive) {
						$array_items = array_merge($array_items, directoryToArray($directory. "/" . $file, $recursive));
					}
					$file = $directory . "/" . $file;
					$array_items[] = preg_replace("/\/\//si", "/", $file);
				} else {
					$file = $directory . "/" . $file;
					$array_items[] = preg_replace("/\/\//si", "/", $file);
				}
			}
		}
		closedir($handle);
	}
	return $array_items;
}
//End Borrowed Code. 
//Use the directoryToArray function to read in the
//filenames into the files array.
if ($files = directoryToArray($imagesdir, false)) {

//The image variable gets a random value from the array. Here is how:  RAND(om)
//starts its result set at 0 (lowest possible value) and ends at the highest
//number in the array by COUNT(ing) the results and subtracting 1.
$image = rand(0, count($files)-1);

//Echo the starting HTML tags for the image. Add a img.random CSS definition to
//the file that includes this one to customize how the image looks.
echo "<img class=\"random\" src=\"";

//Echo a random image from the array.                                                                                       
echo $files[$image];

//Echo the closing HTML tags for the image.  
echo "\" alt=\"random image\" />"; 


//If images can't be used, complain.   
}
else{
   echo ("<p>Image directory or images can not be opened.</p>");
}
}
?>

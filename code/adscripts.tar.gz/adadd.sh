#!/bin/bash
#This is an ugly and simple script that will create  users, groups and computers in an AD environment. 
#
#Most of the information I used to create this script was grabbed from http://pig.made-it.com/pig-adusers.html.  
#
#Expectations and Limitations:
#
#See the adquery script for an explination of how your OU structure should look for these scripts to work. 
#
#Since I won't be using it frequently, I didn't spend a lot of time trying to get the user add part perfect.  Right now, when users are created their first and last names are set to whatever ID you feed the script and their account is locked.  You will need to pull up the MS GUI and have the user fill in their correct information, choose a password and unlock their account.  Correct info would be easy to do in this script, password stuff is a bit more complicated but should be doable.
#
#I left some very useful but not required attributes out of the user add section since they aren't useful to me.  Check them out, they may be useful to you. 
#
#NOTE: I threw this together quickly as a proof of concept project.  If you intend to use it in production, you should really do some heavy testing as well as some code extending and cleanup first. 

#DM

#Debugging
#set -x 


#############
#VARIABLES
#############
#Must be an OU admin. 
ADUSER="dminnich@domain.local"
#yes, this is a security risk.
#Replace all instances of -w ${ADPASS} with -W to get prompted instead. 
ADPASS="XXXXXXXXX"
#comain controller
DC="dc.domain.local"
#gets prepended to your computer names.  My enviornment has naming standards, you can ignore this.
CDPTID=""
#gets appended to your user names. My enviornment has naming standards, you can ignore this.
UDPTID=""
#gets prepended to your group names. My enviornment has naming standards, you can ignore this. 
GDPTID=""
#global things used in building attributes
DOMAINSUFFIX="domain.local"
LDAPDOMAIN="DC=domain,DC=local"
#Where your stuff is.  A flat architecture is assumed. 
#My environment has things broken up into OUs structures for each department. 
DEFAULTOU="OU=ORG,DC=domain,DC=local"
COMPUTEROU="OU=Computers,${DEFAULTOU}"
GROUPOU="OU=Groups,${DEFAULTOU}"
USEROU="OU=Users,${DEFAULTOU}"
DOMAINSUFFIX="domain.local"
LDAPDOMAIN="DC=domain,DC=local"

################
#SANITY CHECKS
################
if [ $# -ne 2 -a $# -ne 4 ]; then
echo "Usage... 
      `basename $0` -c|-u|-g object [-s sub-ou]"
exit 1
fi

if [ "$1" != "-c" -a "$1" != "-u" -a "$1" != "-g" ]; then 
echo "Usage... 
      `basename $0` -c|-u|-g object [-s sub-ou]"
exit 1
fi

if [ $# -eq 4 -a "$3" != "-s" ]; then
echo "Usage... 
      `basename $0` -c|-u|-g object [-s sub-ou]"
exit 1
fi


###################
#SUB-OU Def
###################

if [ -n "${4}" ]; then
CUSTOMOU=`ldapsearch -x -H ldap://${DC} -D "${ADUSER}" -LLL -b "${DEFAULTOU}" -w ${ADPASS} "(ou=${4})" | grep dn | cut -d" " -f2`
COMPUTEROU=${CUSTOMOU}
GROUPOU=${CUSTOMOU}
USEROU=${CUSTOMOU}
DEFAULTOU=${CUSTOMOU}
if [ "$?" -ne "0" ]; then
echo -e "\e[00;31m I was unable to find the specified sub-ou information. Exiting.\e[00m"
exit 1
fi
fi


#remove any past runs.  
rm -f adadd.ldif


###################
#COMPUTER
##################
if [ "${1}" == "-c" ]; then
HOST="${CDPTID}${2}"
echo "dn: CN=${HOST},${COMPUTEROU}" >> adadd.ldif
echo "changetype: add" >> adadd.ldif
echo "objectClass: top" >> adadd.ldif
echo "objectClass: person" >> adadd.ldif
echo "objectClass: organizationalPerson" >> adadd.ldif
echo "objectClass: user" >> adadd.ldif
echo "objectClass: computer" >> adadd.ldif
echo "cn: ${HOST}" >> adadd.ldif
echo "distinguishedName: CN=${HOST},${COMPUTEROU}" >> adadd.ldif
echo "objectCategory: CN=Computer,CN=Schema,CN=Configuration,${LDAPDOMAIN}" >> adadd.ldif
echo "instanceType: 4" >> adadd.ldif
echo "displayName: ${HOST}$" >> adadd.ldif
echo "name: ${HOST}" >> adadd.ldif
echo "userAccountControl: 4096" >> adadd.ldif
echo "codePage: 0" >> adadd.ldif
echo "countryCode: 0" >> adadd.ldif
echo "accountExpires: 0" >> adadd.ldif
echo "sAMAccountName: ${HOST}$" >> adadd.ldif
echo "dNSHostName: ${HOST}.${DOMAINSUFFIX}" >> adadd.ldif
echo "servicePrincipalName: HOST/${HOST}" >> adadd.ldif
echo "servicePrincipalName: HOST/${HOST}.${DOMAINSUFFIX}" >> adadd.ldif

ldapmodify -x -H ldap://${DC} -D "${ADUSER}" -f adadd.ldif -w ${ADPASS}
if [ "$?" -ne "0" ]; then
echo -e "\e[00;31m I was unable to create the computer object. Exiting.\e[00m"
exit 1
else
echo "Computer object successfully added!"
fi

fi


##################
#USER
#################
#Accounts are created in a disabled state.  Also, note that some of the information inserted is wrong.  Mainly, everybody gets their account name everywhere, including where their real name should be.  These things aren't a big for me.  Note that their may be other ways to do this, the link at the top suggested some, I just didn't spend time trying them because it isn't necessary in my environment.     
if [ "${1}" == "-u" ]; then
USER="${2}${UDPTID}"
echo "dn: CN=${USER},${USEROU}" >> adadd.ldif
echo "changetype: add" >> adadd.ldif
echo "objectClass: top" >> adadd.ldif
echo "objectClass: person" >> adadd.ldif 
echo "objectClass: organizationalPerson" >> adadd.ldif 
echo "objectClass: user" >> adadd.ldif 
echo "objectCategory: CN=Person,CN=Schema,CN=Configuration,${LDAPDOMAIN}" >> adadd.ldif
echo "codePage: 0" >> adadd.ldif 
echo "countryCode: 0" >> adadd.ldif 
echo "distinguishedName: CN=${USER},${USEROU}" >> adadd.ldif 
echo "cn: ${USER}" >> adadd.ldif
echo "sn: ${USER}" >> adadd.ldif 
echo "givenName: ${USER}" >> adadd.ldif 
echo "displayName: ${USER}" >> adadd.ldif 
echo "name: ${USER}" >> adadd.ldif
#echo "telephoneNumber: 123456" >> adadd.ldif
echo "instanceType: 4" >> adadd.ldif
echo "userAccountControl: 514" >> adadd.ldif
echo "accountExpires: 0" >> adadd.ldif
#echo "uidNumber: 600" >> adadd.ldif
#echo "gidNumber: 600" >> adadd.ldif 
echo "sAMAccountName: ${USER}" >> adadd.ldif
echo "userPrincipalName: ${USER}@${DOMAINSUFFIX}" >> adadd.ldif 
#altSecurityIdentities: Kerberos:pprutser@EXAMLE.COM
echo "mail: ${USER}@${DOMAINSUFFIX}" >> adadd.ldif
#homeDirectory: \\ads\home\pprutser 
#homeDrive: Z: 
#unixHomeDirectory: /home/pprutser 
#loginShell: /bin/bash 


ldapmodify -x -H ldap://${DC} -D "${ADUSER}" -f adadd.ldif -w ${ADPASS}
if [ "$?" -ne "0" ]; then
echo -e "\e[00;31m I was unable to create the user object. Exiting.\e[00m"
exit 1
else
echo "User object successfully added!"
fi
fi


#################
#GROUP
################
if [ "${1}" == "-g" ]; then
GROUP="${GDPTID}${2}"
echo "dn: CN=${GROUP},${GROUPOU}" >> adadd.ldif
echo "changetype: add" >> adadd.ldif
echo "objectClass: top" >> adadd.ldif
echo "objectClass: group" >> adadd.ldif
echo "objectCategory: CN=Group,CN=Schema,CN=Configuration,${LDAPDOMAIN}" >> adadd.ldif
echo "cn: ${GROUP}" >> adadd.ldif
echo "name: ${GROUP}" >> adadd.ldif
echo "distinguishedName: CN=${GROUP},${GROUPOU}" >> adadd.ldif
echo "instanceType: 4" >> adadd.ldif
echo "sAMAccountName: ${GROUP}" >> adadd.ldif

ldapmodify -x -H ldap://${DC} -D "${ADUSER}" -f adadd.ldif -w ${ADPASS}
if [ "$?" -ne "0" ]; then
echo -e "\e[00;31m I was unable to create the group object. Exiting.\e[00m"
exit 1
else
echo "Group object successfully added!"
fi
fi



exit 0


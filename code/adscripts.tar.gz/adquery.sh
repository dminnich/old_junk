#!/bin/bash
#This is an ugly and simple script that will query an active directory environment. 
#
#Usage notes:
#Searching for ALL will give you a list of all objects in that OU.  
#
#If what you are searching for includes a space, quote it. 
#
#Expectations and Limitations:
#Your OU structure should look like this:
#**ORG
#****Computers
#****Groups
#****Users
#****LabA-Computers
#****LabA-Groups
#****LabA-Users
#Each sub-OU should be hanging off the top of your default OU as these scripts don't currently support recursion.  
#Each OU and each object in each OU should have globally unique names.
#You should not mix different typed objects in one OU.  In other words, LabA-Computers should just have computer objects and not computer and user objects.  
#
#Not following these guidelines will lead to unexpected behavior when multiple objects have the same name.  Also, you will only be able to go one level deep.  Finally, mixing objects of different types isn't a huge deal, just don't expect the search results to be smart enough to only find computers when you use the -c search criteria when also put users in that OU.  
#
#NOTE: I threw this together quickly as a proof of concept project.  If you intend to use it in production, you should really do some heavy testing as well as some code extending and cleanup first. 

#DM

#Debugging
#set -x 


#############
#VARIABLES
#############
#Must be an OU admin. 
ADUSER="dminnich@domain.local"
#yes, this is a security risk.
#Replace all instances of -w ${ADPASS} with -W to get prompted instead. 
ADPASS="XXXXXXXX"
#domain controller
DC="dc.domain.local"
#gets prepended to your group names. My enviornment has naming standards, you can ignore this. 
GDPTID=""
#Where your stuff is.  A flat architecture is assumed. 
#My environment has things broken up into OUs structures for each department. 
DEFAULTOU="OU=ORG,DC=domain,DC=local"
COMPUTEROU="OU=Computers,${DEFAULTOU}"
GROUPOU="OU=Groups,${DEFAULTOU}"
USEROU="OU=Users,${DEFAULTOU}"

################
#SANITY CHECKS
################
if [ $# -ne 2 -a $# -ne 4 ]; then
echo "Usage... 
      `basename $0` -c|-u|-g|-o object|ALL [-s sub-ou]"
exit 1
fi

if [ "$1" != "-c" -a "$1" != "-u" -a "$1" != "-g" -a "$1" != "-o" ]; then 
echo "Usage... 
      `basename $0` -c|-u|-g|-o object|ALL [-s sub-ou]"
exit 1
fi

if [ $# -eq 4 -a "$3" != "-s" ]; then
echo "Usage... 
      `basename $0` -c|-u|-g|-o object|ALL [-s sub-ou]"
exit 1
fi


###################
#SUB-OU Def
###################

if [ -n "${4}" ]; then 
CUSTOMOU=`ldapsearch -x -H ldap://${DC} -D "${ADUSER}" -LLL -b "${DEFAULTOU}" -w ${ADPASS} "(ou=${4})" | grep dn | cut -d" " -f2`
COMPUTEROU=${CUSTOMOU}
GROUPOU=${CUSTOMOU}
USEROU=${CUSTOMOU}
DEFAULTOU=${CUSTOMOU}
if [ "$?" -ne "0" ]; then
echo -e "\e[00;31m I was unable to find the specified sub-ou information. Exiting.\e[00m"
exit 1
fi
fi


###################
#COMPUTER
##################
	if [ "${1}" == "-c" ]; then
#you can use keyword ALL to get a list of all the computers. 
if [ "${2}" == "ALL" ]; then
ldapsearch -x -H ldap://${DC} -D "${ADUSER}" -LLL -b "${COMPUTEROU}" -w ${ADPASS} | grep "^dn: CN.*"
else
ldapsearch -x -H ldap://${DC} -D "${ADUSER}" -LLL -b "${COMPUTEROU}" -w ${ADPASS} "(cn=${2})"
fi

if [ "$?" -ne "0" ]; then
echo -e "\e[00;31m I was unable to search for the computer object. Exiting.\e[00m"
exit 1
fi

	fi


##################
#USER
#################
	if [ "${1}" == "-u" ]; then
#you can use keyword ALL to get a list of all the computers. 
if [ "${2}" == "ALL" ]; then
ldapsearch -x -H ldap://${DC} -D "${ADUSER}" -LLL -b "${USEROU}" -w ${ADPASS} | grep "^dn: CN.*"
else
ldapsearch -x -H ldap://${DC} -D "${ADUSER}" -LLL -b "${USEROU}" -w ${ADPASS} "(cn=${2})"
fi

if [ "$?" -ne "0" ]; then
echo -e "\e[00;31m I was unable to search for the user object. Exiting.\e[00m"
exit 1
fi

	fi


#################
#GROUP
################

	if [ "${1}" == "-g" ]; then
#you can use keyword ALL to get a list of all the computers. 
if [ "${2}" == "ALL" ]; then
ldapsearch -x -H ldap://${DC} -D "${ADUSER}" -LLL -b "${GROUPOU}" -w ${ADPASS} | grep "^dn: CN.*"
else
ldapsearch -x -H ldap://${DC} -D "${ADUSER}" -LLL -b "${GROUPOU}" -w ${ADPASS} "(cn=${2})"
fi

if [ "$?" -ne "0" ]; then
echo -e "\e[00;31m I was unable to search for the group object. Exiting.\e[00m"
exit 1
fi

	fi

###################
#OU
##################
	if [ "${1}" == "-o" ]; then
#you can use keyword ALL to get a list of all the computers. 
if [ "${2}" == "ALL" ]; then
ldapsearch -x -H ldap://${DC} -D "${ADUSER}" -LLL -b "${DEFAULTOU}" -w ${ADPASS} | grep "^dn: OU.*" 
else
ldapsearch -x -H ldap://${DC} -D "${ADUSER}" -LLL -b "${DEFAULTOU}" -w ${ADPASS} "(ou=${2})"
fi

if [ "$?" -ne "0" ]; then
echo -e "\e[00;31m I was unable to search for the OU object. Exiting.\e[00m"
exit 1
fi

	fi



exit 0

#!/bin/bash
#This is an ugly and simple script that will delete objects in an active directory environment. 
#
#Expectations and Limitations:
#
#See the adquery script for an explination of how your OU structure should look for these scripts to work
#
#NOTE: I threw this together quickly as a proof of concept project.  If you intend to use it in production, you should really do some heavy testing as well as some code extending and cleanup first. 

#DM

#Debugging
#set -x 


#############
#VARIABLES
#############
#Must be an OU admin. 
ADUSER="dminnich@domain.local"
#yes, this is a security risk.
#Replace all instances of -w ${ADPASS} with -W to get prompted instead. 
ADPASS="XXXXXXXX"
#domain controller
DC="dc.domain.local"
#gets prepended to your group names. My enviornment has naming standards, you can ignore this. 
GDPTID=""
#Where your stuff is.  A flat architecture is assumed. 
#My environment has things broken up into OUs structures for each department. 
DEFAULTOU="OU=ORG,DC=domain,DC=local"
COMPUTEROU="OU=Computers,${DEFAULTOU}"
GROUPOU="OU=Groups,${DEFAULTOU}"
USEROU="OU=Users,${DEFAULTOU}"

################
#SANITY CHECKS
################
if [ $# -ne 2 -a $# -ne 4 ]; then
echo "Usage... 
      `basename $0` -c|-u|-g object [-s sub-ou]"
exit 1
fi

if [ "$1" != "-c" -a "$1" != "-u" -a "$1" != "-g" ]; then 
echo "Usage... 
      `basename $0` -c|-u|-g object [-s sub-ou]"
exit 1
fi

if [ $# -eq 4 -a "$3" != "-s" ]; then
echo "Usage... 
      `basename $0` -c|-u|-g object [-s sub-ou]"
exit 1
fi


###################
#SUB-OU Def
###################

if [ -n "${4}" ]; then 
CUSTOMOU=`ldapsearch -x -H ldap://${DC} -D "${ADUSER}" -LLL -b "${DEFAULTOU}" -w ${ADPASS} "(ou=${4})" | grep dn | cut -d" " -f2`
COMPUTEROU=${CUSTOMOU}
GROUPOU=${CUSTOMOU}
USEROU=${CUSTOMOU}
DEFAULTOU=${CUSTOMOU}
if [ "$?" -ne "0" ]; then
echo -e "\e[00;31m I was unable to find the specified sub-ou information. Exiting.\e[00m"
exit 1
fi
fi


###################
#COMPUTER
##################
	if [ "${1}" == "-c" ]; then
ldapdelete -x -H ldap://${DC} -D "${ADUSER}" -w ${ADPASS} "CN=${2},${COMPUTEROU}"

if [ "$?" -ne "0" ]; then
echo -e "\e[00;31m I was unable to delete the computer object. Exiting.\e[00m"
exit 1
else
echo "Computer object successfully deleted."
fi

	fi


##################
#USER
#################
	if [ "${1}" == "-u" ]; then
ldapdelete -x -H ldap://${DC} -D "${ADUSER}" -w ${ADPASS} "CN=${2},${USEROU}"

if [ "$?" -ne "0" ]; then
echo -e "\e[00;31m I was unable to delete the user object. Exiting.\e[00m"
exit 1
else 
echo "User object successfully deleted."
fi

	fi


#################
#GROUP
################
	if [ "${1}" == "-g" ]; then
ldapdelete -x -H ldap://${DC} -D "${ADUSER}" -w ${ADPASS} "CN=${2},${GROUPOU}"

if [ "$?" -ne "0" ]; then
echo -e "\e[00;31m I was unable to delete the group object. Exiting.\e[00m"
exit 1
else 
echo "Group object successfully deleted."
fi

	fi


exit 0

<?php
#This is a simple script that will allow users to share large files with people
#around the world.  I'm a terrible coder and copy-pasted most of this from
#various places on the web.  
#DM

######################
###SCRIPT SETTINGS...
######################
#max file size in bytes - 3GB
$max_size="3221225472";
#filesystem path to the folder that will store all the uploads
#no trailing slash
$root_folder="/var/www/html/uploads";
#a dated folder plus some random digits and the source filename
#will be appended to this link when creating download links 
#no trailing slash
$base_url="http://example.com/uploads";
#date is sysadmin format.  will be used in folder names
#to store each file in a unique folder.  also gives end users
#and us a good way to know when files are expiring. 
$date = date('Ymd');
#a random number. this is appended to the date when the
#folder that houses the uploaded file is created.  
#hopefully significantly fewer than a million uploads will 
#happen ever day.  otherwise, we will hit randomness errors.
$rand = rand(0, 999999);
#combination of the above two will be the folder name
$folder = $date . "-" . $rand;
$site_title = "Simple PHP File Sharer";
$support_email = "user@example.com";
$cssfile = "sfs.css";

############################
###CODE...
############################

//IF SUBMIT HASN'T BEEN CLICKED.  SHOW ORIGINAL PAGE
if (!isset($_POST['submit'])) {
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
 "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<link rel="stylesheet" type="text/css" href="<?php echo $cssfile;?>" />
<title><?php echo $site_title; ?></title>
</head>
<body class="sfs">
<h1 class="sfs"> <?php echo $site_title; ?></h1>
<?php include("intro.php"); ?>
<div class="sfs">
<form class="sfs" enctype="multipart/form-data" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<!-- <input type="hidden" name="MAX_FILE_SIZE" value="<?php echo $max_size; ?>" /> -->
<input class="sfs" name="uploadedfile" type="file" /><br />
<br />
<?php include("tos.php"); ?>
<br />
<br />
<input class="sfs" type="checkbox" name="TOS" value="TOS" /> I accept the TOS.
<br />
<input class="sfs" type="submit" name="submit" value="Upload File" />
</form>
</div>
</body>
</html>
<?php
}
?>




<?php

//IF SUBMIT HAS BEEN CLICKED
if(isset($_POST['submit'])) {

###VARS
#user file basename
$file = basename($_FILES['uploadedfile']['name']);
#upload path
$upload_folder = "$root_folder/$folder/";
//debug/$upload_folder = "/var/www/html/uploads/good/";
#full upload path
$upload_path = "$root_folder/$folder/$file";
//debug/$upload_path = "/var/www/html/uploads/good/a";
#destination url
$final_url = "$base_url/$folder/$file";
//debug/echo $_FILES["uploadedfile"]["size"];

##ERROR HANDLING
#if TOS were not agreed to, bomb out
	if(!isset($_POST['TOS'])) {
        ?>
                <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
                "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
                <html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
                <head>
		<link rel="stylesheet" type="text/css" href="<?php echo $cssfile;?>" />
                <title><?php echo $site_title; ?> - Error</title>
                </head>
                <body class="sfs">
                <h1 class="sfs"> <?php echo $site_title; ?> - Error </h1>
                <p class="sfs">File upload failed! <br />
		 You must agree to the Terms of Service to upload a file.<br /> <br />
                <a class="sfs" href="javascript:history.back()">Go back</a> </p>
                </body>
                </html>
                <?php
		exit;
                }//END TOS AGREED TO CHECK


#if the file has a weird character in it, bomb out.
#simple input validation protection.  
		#http://www.phpjabbers.com/php-validation-and-verification-php27.html
		#also bomb here if they don't choose a file.  
		if ((empty($_FILES["uploadedfile"])) || (preg_match("/^[a-zA-Z0-9. _-]+$/", $file) === 0)) {
	         ?>
                <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
                "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
                <html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
                <head>
		<link rel="stylesheet" type="text/css" href="<?php echo $cssfile;?>" />
                <title><?php echo $site_title; ?> - Error</title>
                </head>
                <body class="sfs">
                <h1 class="sfs"> <?php echo $site_title; ?> - Error </h1>
                <p class="sfs"> File upload failed! <br />
		Your file's name can only contain alphanumeric characters, spaces, dashes, underscores and periods.<br /> <br />
                <a class="sfs" href="javascript:history.back()">Go back</a> </p>
                </body>
                </html>
                <?php
		exit;
		}//END FILENAME WEIRD CHARACTER CHECK
		
#if the file or folder already exist, bomb out
              if ((file_exists($upload_folder)) || (file_exists($upload_path))) {
                 ?>
                <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
                "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
                <html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
                <head>
		<link rel="stylesheet" type="text/css" href="<?php echo $cssfile;?>" />
                <title><?php echo $site_title; ?> - Error</title>
                </head>
                <body class="sfs">
                <h1 class="sfs"> <?php echo $site_title; ?> - Error </h1>
                <p class="sfs"> File upload failed! <br />
		Randomness error. <br />
		Please go back and try again.  <br />
		If you receive this error multiple times in a row, please contact <?php echo $support_email; ?>.<br /> <br />
                <a class="sfs" href="javascript:history.back()">Go back</a> </p>
                </body>
                </html>
                <?php
                exit;
                }//END FILE EXIST CHECKS

#if the file is to large, bomb out
	     if ($_FILES['uploadedfile']['size'] > $max_size) {
	//debug/ if ($_FILES['uploadedfile']['size'] > 300) {
                 ?>
                <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
                "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
                <html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
                <head>
		<link rel="stylesheet" type="text/css" href="<?php echo $cssfile;?>" />
                <title><?php echo $site_title; ?> - Error</title>
                </head>
                <body class="sfs">
                <h1 class="sfs"> <?php echo $site_title; ?> - Error </h1>
                <p class="sfs">File upload failed!  <br />
		 The file you uploaded was too large. <br />
                Your file can only be <?php echo $max_size; ?> bytes in size.  <br /><br />
                <a class="sfs" href="javascript:history.back()">Go back</a> </p>
                </body>
                </html>
                <?php
                exit;
                }//END FILE SIZE CHECK



###
#Create the folder and set the permissions
mkdir($upload_folder, 0777);
chmod($upload_folder, 0777);
#make sure it worked. if not, bomb
	if (!is_writable($upload_folder)){
?>
     	    <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
                "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
                <html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
                <head>
		<link rel="stylesheet" type="text/css" href="<?php echo $cssfile;?>" />
                <title><?php echo $site_title; ?> - Error</title>
                </head>
                <body class="sfs">
                <h1 class="sfs"> <?php echo $site_title; ?> - Error </h1>
                <p class="sfs"> File upload failed!  <br />
		Permissions error. <br />
		Please go back and try again.  <br />
                If you receive this error multiple times in a row, please contact <?php echo $support_email; ?>.<br /> <br />
                <a class="sfs" href="javascript:history.back()">Go back</a> </p>
                </body>
                </html>
                <?php
                exit;
                }//END DIRECTORY CREATION CHECK


#Move the temporary file.  
if(move_uploaded_file($_FILES['uploadedfile']['tmp_name'], $upload_path)) {
#if it worked, show the user the link. 
?>
      <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
                "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
                <html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
                <head>
		<link rel="stylesheet" type="text/css" href="<?php echo $cssfile;?>" />
                <title><?php echo $site_title; ?></title>
                </head>
                <body class="sfs">
                <h1 class="sfs"> <?php echo $site_title; ?></h1>
                <p class="sfs"> File upload successfully!  <br />
                Give this link to your peers: <br />
                 <a class="sfs" href="<?php echo $final_url; ?>"><?php echo $final_url; ?></a> <br /> <br />
                <a class="sfs" href="javascript:history.back()">Upload Another</a> </p>
                </body>
                </html>
                <?php
                exit;
} else{
#if it didn't work, bomb out.
?>
	 <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
                "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
                <html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
                <head>
		<link rel="stylesheet" type="text/css" href="<?php echo $cssfile;?>" />
                <title><?php echo $site_title; ?> - Error</title>
                </head>
                <body class="sfs">
                <h1 class="sfs"> <?php echo $site_title; ?> - Error </h1>
                <p class="sfs"> File upload failed!  <br />
                General upload error. <br />
                Please go back and try again.  <br />
                If you receive this error multiple times in a row, please contact <?php echo $support_email; ?>.<br /> <br />
                <a class="sfs" href="javascript:history.back()">Go back</a> </p>
                </body>
                </html>
                <?php
                exit;
                }//END DIRECTORY CREATION CHECK




}//END SUBMIT BUTTON CLICKED CHECK

?>


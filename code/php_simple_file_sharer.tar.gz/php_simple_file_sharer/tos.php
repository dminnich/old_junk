<textarea class="sfs" name="tos" cols="60" rows="18" readonly="readonly">
Terms Of Service:
-The file I'm uploading is not illegal in nature.
-The file I'm uploading is not offensive or pornographic in nature.
-The file I'm uploading will not directly or indirectly damage other living beings or electronic devices.


By checking the “I accept the TOS” box below, you are stating that you have read and will abide by the Terms Of service above.  A checked box also signifies your agreement to be held personally responsible for any troubles that may arise, should you or someone else using your credentials ever upload something that violates these terms of service.
</textarea>

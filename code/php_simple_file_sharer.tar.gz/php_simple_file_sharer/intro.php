<p class="sfs">
This page is an easy way for you to share large files with your colleagues around the world. </p>
<div class="sfs-intro">
<ul class="sfs">
<li class="sfs">File size limit: 3GB</li>
<li class="sfs">Files are deleted after: 30 Days</li>
</ul>
</div>

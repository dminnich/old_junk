This is a simple PHP One Click Upload Script.
-----------------------------------------------
Allows users to upload large files and then send links to those files to their
friends.

Features:
-------------
-Very small.  The entire script is one file.  
-Text file based.  MySQL not needed.  
-Very easy to change. this script uses very straightforward syntax and has
lots of comments.  If you have ever messed with PHP you should be able to
adapt it to fit your needs.
-CSS customizable.  
-completely free.  no links back to my page.  do whatever you like with this
script, i care not.

What this script doesn't do:
-------------------------------
-Allow people to create accounts. 
-Give splash pages for file downloads. 
-Integrate capatcha or ad functionality. 
-Have an affiliate setup. 
-Integrate password protection features.  
-Bandwidth throttling.  
-IP address limiting.  
-Directly delete old files.  Use the cron job below. 
-Allow variable deletion times for files.  
-Work in large environments.  It's randomness algorithm and how it stores
files will lead to problems and poor performance if you get more than a couple
hundread uploads a day and keep files longer than a couple months. 

Who this script is for:
----------------------------
-Me! 
-People who have a small group of trusted users who they want to allow to
share files with others on the web.  I use a combination of front end
authentication and IP based firewalling stuff in my real install.  Since those
things are custom to my environment, they are not included in the script.   
-For people new to PHP (like me).  This is a good script to look at and learn
from and adapt to your needs.

Installation
--------------
1) Upload index.php, intro.php, tos.php and sfs.css to a new folder on your
webhost. 
2) Create an uploads directory in the directory where you placed index.php.
CHMOD this dir 777.  
3) Set the max_size, root_folder, base_url, site_title and support_email
variables in index.php.  How to set them is further described in index.php.
4) Create a daily cron job similar to the following:
/bin/find /md2/uploads/ -type d -mtime +31 -print0 | /usr/bin/xargs -0 -r /bin/rm -Rf
Specify the full path to your uploads directory instead of using /md2.
You also may need to update the path to the find xargs and rm executables. 
+31 specifies how old a file must be before it is deleted.  
Basically, this sets how long download links are good for.  
5) Change the text in the intro.php and tos.php to meet your needs.

Customization
--------------
Change the sfs.css file. 

Hack away at the html inside of index.php.  

Notes
-------
Things to check if you run into problems...
-You need to specify the FULL system path to your uploads directory for the
cron job and for root_folder.  Sometimes hosting providers obscure this
information.  If you can't figure it out, email them or create a php file with
a contents of getcwd(); to see if that will find it for you. 
-file_uploads must be set to ON in your hosting providers php.ini for this
script to work.  
-The varaible that your hosting provider has set for upload_max_filesize and
post_max_size in their php.ini set how big any PHP based upload can be,
regardless of what you set max_size to be in index.php. 
-If your uploads take a long time to complete, your hosting provider may need
to increase the timeouts set in the max_execution_time and max_input_time
variables in their php.ini.  
-You or your hosting provider may be running out of disk space or
upload_tmp_dir disk space which probably isn't even tied to your account.  

If you are running your own web server, you can give all of those settings in
your php.in reasonable values and also do the following:
-Create a folder chmoded 777 named tmp on your large partition that will be
holding all of the uploaded data.  IE: /md2/tmp
-Set upload_tmp_dir to the tmp folder you just created (ie: /md2/tmp).  This
will avoid /tmp exhaustion problems. 
-Run another nightly cron job similar to the following:
/bin/find /md2/tmp/ -type f -mtime +5 -print0 | /usr/bin/xargs -0 -r /bin/rm -Rf
This will delete any half-uploaded or any other weird temporary files that are
still hanging around.  

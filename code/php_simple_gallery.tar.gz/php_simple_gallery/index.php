<?
//Drop this file into a (world-writable) folder of JPEGs and it will create a
//page full of clickable thumbnails.  When these thumbnails are clicked their
//corresponding full size images will be displayed. NOTE: If you would like for
//the full size images to be shown in pop-ups instead of in the same browser
//window there is an option for that later in this script.  

//This script ONLY supports JPGs and it doesn't do anything complicated.  No
//uploading, no tagging, no sub-directory support, no link protection, no
//commenting, no pagination, etc. 
//In other words--IT SHOWS IMAGES.

//NOTE: The directory you put this file in needs to have world writable (777)
//permissions.  

//Get the name of the folder we are currently in. The folder's name will be the
//name of the gallery and it will be displayed in the title bar and in a
//header.
$galleryname =  basename(realpath("."));
#Lets change the underscores in $galleryname to spaces.  A folder like
#"high_school_grad" will show up as "high school grad" when viewing the
#gallery.
$galleryname = str_replace('_',' ',$galleryname);
#Lets make the galleryname Title Case.  A folder like "high school grad" will
#show up as "High School Grad" when viewing the gallery. NOTE: This will also
#change ALL CAPS folders to Title Case.  
$galleryname = ucwords(strtolower($galleryname));

#Set where the script will pull its CSS definitions from.  If you want to use
#your master CSS file instead of sg.css, copy the definitions from sg.css to
#your file and then update the variable below to link to your css file instead.
#Note: You must change this in both PHP files.  
$cssfile = "../sg.css";

#Start the page and the table that will be holding the thumbs
#Javascript notes:
#function reWrite(a,b,c,d) dynamically creates a valid xhtml page that will
#display the full-size image and its $imagename.  I got its base code from 
#http://www.java2s.com/Code/JavaScript/Development/UsingdocumentwriteontheCurrentWindow.htm
#function popup(a,b,c,d) dynamically creates a valid xhtml page in a pop-up
#that will display the full-size image and its $imagname.  I got its base
#code from various sites on the web.  
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<script type="text/javascript">

<!--
function reWrite(a,b,c,d) {
     var newContent = "<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Strict//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd'>"
    newContent += "<html xmlns='http://www.w3.org/1999/xhtml' xml:lang='en' lang='en'>"
    newContent += "<head><link rel='stylesheet' type='text/css' href='"+ d +"' /><title>Simple Gallery:Galleries:"+ a +":"+ b +"</title></head>"
    newContent += "<body class='sg'><h2 class='sg'><a class='sg' href='../'>Galleries</a>:<a class='sg' href='index.php'>"+ a +"</a>:"+ b +"</h2><div class='sg'>"
    newContent += "<img class='sg' src='"+ c +"' alt='"+ b +"' />"
    newContent += "</div></body></html>";

    document.write(newContent);
    document.close();
}
function popup(a,b,c,d) {
var generator=window.open ('','popup');
  var newContent = "<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Strict//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd'>"
    newContent += "<html xmlns='http://www.w3.org/1999/xhtml' xml:lang='en' lang='en'>"
    newContent += "<head><link rel='stylesheet' type='text/css' href='"+ d +"' /><title>Simple Gallery:Galleries:"+ a +":"+ b +"</title></head>"
    newContent += "<body class='sg'><h2 class='sg'><a class='sg' href='../'>Galleries</a>:<a class='sg' href='index.php'>"+ a +"</a>:"+ b +"</h2><div class='sg'>"
    newContent += "<img class='sg' src='"+ c +"' alt='"+ b +"' />"
    newContent += "</div></body></html>";
    generator.document.write(newContent); 
    generator.document.close();
}
-->
</script>
<link rel="stylesheet" type="text/css" href="<?echo $cssfile;?>" />
<title>Simple Gallery:Galleries:<?echo $galleryname;?></title>
</head>
<body class="sg">
<h2 class="sg"><a class="sg" href="../">Galleries</a>:<?echo $galleryname;?> <br /></h2>
<div class="sg">
<table class="sg">
<tr class="sg">
<?


#First we need to create thumbnails for the images that don't already have
#them.  These thumbnails will be stored in a "thumbs" sub-directory. 
#Lets define the "thumbs" directory. 
$thumbdir = "thumbs";
#If the directory doesn't exist we need to create it before we move on. 
if(!is_dir("$thumbdir"))
{
mkdir("$thumbdir");
}
#If the directory does exist or if was just created we can move on.   

#Later on in the script we will need to count how many images there are in this
#directory.  In order to do this we will increase $filecount by 1 every time a
#JPG is found. We will define filecount here and give it an initial value of 0.
$filecount = "0";

#If we can open the directory we are in, continue.
if ($currentdir = opendir ("./"))
{
#Loop through all the files in the directory
        while (false !== ($file = readdir($currentdir))) {
#If the file has a JPG, JPEG, jpg, jpeg extension...
if ( preg_match('/^.*\.jpe?g$/i', $file ))
{
#We have to "open" each image to use the gd "imagecreatefromjpg" function. 
$fp = @fopen("$file","r");

#If a file with this name doesn't already exist in the thumbnail directory, we
#need to create a thumbnail for it.  
if (!is_file($thumbdir."/".$file))
{
#We will be creating a new jpeg from the original image. We will call this
#new image "bigimage" and for now it will be stored in a buffer area.  
$bigimage = imagecreatefromjpeg("$file");
#Get the height and the width of the original image.
$bigwidth = imagesx($bigimage);
$bigheight = imagesy($bigimage);

#Now it is time to do some confusing calculations.  We need to resize the
#images while making sure they stay proportional. Pictures can either have way
#more height than width or way more width than height.  For this reason we will
#need to calculate two ratios, compare them, and do a resize based on the
#highest ratio.

#First we need to define the maximum height OR width we would like to see a
#thumbnail have. 
$maxthumbwidth = "150";
$maxthumbheight = "100";
#Calculate the width ratio by dividing the width of the original image by the
#maxthumbwidth.
$widthratio = $bigwidth/$maxthumbwidth;
#Calculate the height ratio by dividing the height of the original image by
#the maxthumbheight.
$heightratio = $bigheight/$maxthumbheight;
#If the widthratio is larger than the heightratio divide the original images
#height by the widthratio to see what the height will have to be scaled down
#to look right with the now decided upon thumbnail width being
#maximumthumbwidth.  
if($widthratio>$heightratio) {
#Define the thumbnails final width
$thumbwidth = $maxthumbwidth;
#Define the thumbnails final height
$thumbheight = $bigheight/$widthratio;
}
#Else, if the height ratio is bigger, the thumbnail will be maxthumbheight
#pixels tall and we will need to calculate the corresponding width by dividing
#the original images width by the height ratio.  
else {
$thumbheight = $maxthumbheight;
$thumbwidth = $bigwidth/$heightratio;
}
#We now need to create another image in our buffer.  This image will be the
#size that the thumbnail will end up being.  
$thumbnail=ImageCreateTrueColor($thumbwidth,$thumbheight);
#Actually resize the original image (bigimage in our buffer) to fit into the
#thumbnail image we just created in our buffer.  Note: you can change this to
#imagecopyresampled for better quality thumbnails.  
imagecopyresized($thumbnail,$bigimage,0,0,0,0,$thumbwidth,$thumbheight,$bigwidth,$bigheight);
#Save the thumbnail image in the buffer to the thumbnail directory on the file
#system.
imagejpeg($thumbnail,$thumbdir."/".$file);
#Now that the thumbnail is saved to the file system, we can delete the images
#in our buffer. 
imagedestroy($bigimage);
imagedestroy($thumbnail);
}
#We now need to display all the thumbnails in the table. These thumbnails will
#be clickable and will open their corresponding full size images in the same
#browser window.  
#How many columns should the table have?
$cols = "5";

#Let's create a variable called imagename.  This will be displayed above the
#full-sized image if you choose to use the "image name" echo statements below.
#Basically, this will convert the images filename to something slightly more
#pretty. 
#We need to get the filename without the extension.  
$imagename = preg_replace( '/\.[a-z0-9]+$/i' , '' , $file );
#Replace all underscores with spaces.
$imagename = str_replace('_',' ',$imagename);
#Convert output to Title Case
$imagename = ucwords(strtolower($imagename));

#Start displaying images in the row we already started at the top of this
#file.  
#Start cell.  Link to the full size image.
echo "<td class=\"sg\"><a class=\"sg\" href=\"$file\">";
#Want to display the image name on the full-size image viewing page? If so,
#comment out the above echo line and un-comment the line below this.
#Start cell. Feed the javascript function the galleryname and $file variables. 
//echo "<td class=\"sg\"><a class=\"sg\" onclick=\"reWrite('$galleryname','$imagename','$file','$cssfile')\">";
#Want your full size images to be shown in pop-ups instead of in the current
#browser window? If so, un-comment the below echo line and comment out the echo
#line before this blurb.   
#Start cell.  Link to the full size image in a pop-up. 
//echo "<td class=\"sg\"><a class=\"sg\" onclick=\"window.open(this.href,'_blank');return false;\" href=\"$file\">";
#Want your full size images to be shown in pop-ups and have their image name
#displayed above them? If so, un-comment the below echo line and comment out any
#echo lines before this (in this blurb of code).  
//echo "<td class=\"sg\"><a class=\"sg\" href=\"javascript:popup('$galleryname','$imagename','$file','$cssfile');\">";

#Show the thumbnail.  End the link. End the cell.  Do it again. 
echo "<img class=\"sg\" src=\"$thumbdir/$file\" alt=\"$file\" /></a> </td>";
#Want to display the image name on the gallery page? If so, comment out the
#above echo line and un-comment the line below this.
//echo "<img class=\"sg\" src=\"$thumbdir/$file\" alt=\"$file\" /> <br /> $file</a></td>";

#We will need to count how many images there are. To do this we will increase
#$filecount by 1 every time it goes through this loop. 
$filecount +=1;
#If the number of images is now divisible by the number of columns you want in
#the table (without leaving a remainder) end the table row and start a new one.
#The final remainders will also be shown--the row that holds them just won't be
#full.  
if ( $filecount % $cols == 0 ) { echo "</tr><tr class=\"sg\">"; }
}
#End while.  The script has looked at all the files.
}
#End the table and the page. 
#NOTE:
#We need to create one extra empty cell in order to meet XHTML spec.  If the
#number of table columns and the amount of images divide evenly there will be
#one extra row containing just one empty cell after all the even rows of
#images.  If the last row is not full of images (there should be at least one
#empty column) an additional empty cell will be added.  Note: We need to do
#this because XHTML spec does not allow empty table rows (<tr></tr>) and
#otherwise the even divides would create this situation.  
echo "<td class=\"sg\"></td></tr></table></div></body></html>";
}
#If we couldn't open the directory complain. Note: This should never be
#displayed since this file is in the directory as well.  If you were unable to
#open the directory at all you would likely see a web server Forbidden message.
else 
{
echo
"<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\"
    \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">
<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"en\" lang=\"en\">
<head>
<link rel=\"stylesheet\" type=\"text/css\" href=\"$cssfile\" />
<title>Simple Gallery: Error </title>
</head>
<body class=\"sg\">
<h2 class=\"sg\"> Simple Gallery: Error </h2>
<p class=\"sg\">I was unable to open the directory that holds the galleries.  Permissions??</p>
</body>
</html>";
}
#Close directory
closedir ($currentdir);
?>

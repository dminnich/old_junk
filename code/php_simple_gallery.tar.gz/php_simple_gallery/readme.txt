This is a simple PHP Image Gallery Script.
--------------------------------------------------------
It creates thumbnails out of a folder of images (jpegs). It then displays these
thumbnails in a table and when they are clicked their full size counter parts
are loaded.  Additionally, a random image out of each gallery will provide a
preview of the gallery and be a link to enter the gallery.  

Features:
-------------
-Very simple.  Add a file to a folder of JPEGs and you are done!  
-Thumbnail size and the amount of columns in the table are customizable.  
-Very small.  
-Text file based.  MySQL not needed.
-Very easy to change. This script uses very straightforward syntax and has lots
of comments.  If you have ever messed with PHP you should be able to adapt it
to fit your needs.  
-CSS customizable.
-XHTML compliant. 
-Easy to integrate into your current page.
-Completely free.  No links back to my page.  Do whatever you like with this
script, I care not.

What this script doesn't do:
-------------------------------
-Support any image format other than JPEG.  
-Drill down into sub-directories.  
-Allow you to upload files.  
-Allow you to categorize or "tag" images. 
-Allow you to add descriptions to images or galleries.   
-Paginate galleries.  
-Allow you to manage the script through any type of management interface.
-Have multiple user support.  
-Have support for multiple languages.  
-Protect your images or links from people downloading them.  
-Allow people to comment on your images.  
-Allow people to rate pictures.
-Allow you to password protect certain galleries.  
-Show or index any other type of files.  

Who this script is for:
----------------------------
-Me!
-People who want a simple drop-in image gallery solution and don't need the
features of the better scripts out there.  
-People who do not have access to a MySQL server.
-For people new to PHP (like me).  This is a good script to look at and learn
from and adapt to your needs.



Installation
--------------
If Your Hosting Provider Runs Apache (almost everyone):
Create a directory structure like the following by uploading the files in this
script and your galleries..  
/pics/nothumb.png
/pics/mainindex.php
/pics/index.php
/pics/.htaccess
/pics/sg.css
/pics/2007 Beach Trip/index.php 
Any random folder full of images you upload.  You must copy index.php to every
folder full of images you want to use this script for.  Also, make sure the
folder full of images is world writable (chmod 777).  
/pics/2006 Mountain Trip/index.php 
Any random folder full of images you upload.  You must copy
index.php to every folder full of images you want to use this script for.
Also, make sure the folder full of images is world writable (chmod 777).
And so on.

Go to the site!  You are done!  Don't like the gallery preview page?  Want your
full-size images to come up in pop-ups?  Want the names of the files to be
shown with the images? Don't like the size of the thumbnails?  Think its all
around ugly? See the "Customization" section for different options and tips.  


If Your Hosting Provider Runs Another Web Server:
Create a directory structure like the following by uploading the files in this
script and your galleries..  
/pics/nothumb.png
/pics/mainindex.php
/pics/index.php
/pics/sg.css
/pics/2007 Beach Trip/index.php 
Any random folder full of images you upload.  You must copy index.php to every
folder full of images you want to use this script for.  Also, make sure the
folder full of images is world writable (chmod 777).  
/pics/2006 Mountain Trip/index.php 
Any random folder full of images you upload.  You must copy
index.php to every folder full of images you want to use this script for.
Also, make sure the folder full of images is world writable (chmod 777).
And so on.
--Once you are done copying index.php to your galleries you will need to rename
/pics/index.php to /pics/index.php.bak 
--Then you will need to rename /pics/mainindex.php to /pics/index.php.  
--In the future, when you add more galleries, you will copy /pics/index.php.bak
to /pics/New Gallery/index.php.  

Go to the site!  You are done!  Don't like the gallery preview page?  Want your
full-size images to come up in pop-ups?  Want the names of the files to be
shown with the images? Don't like the size of the thumbnails? Think its all
around ugly? See the "Customization" section for different options and tips.  



Customization
-------------------
The appearance of the page can be changed by making changes to the sg.css file.
You can also copy the CSS definitions out of sg.css into your sites main CSS
file.  If you choose to do this you must update the $cssfile variable in both
script files so that it points to your sites main CSS file.   

If you would like to change the hard-coded HTML output simply open the PHP
files, find it, and have at it.  Most of the code can be found by searching for
"page".  Generally there is a "start page" and "end page" section.  In addition
to this there are two "echo" lines that write the table cells that contain the
thumbnails or the gallery previews approximately in the center of the PHP
files.  Searching for echo "<td should reveal them.  

If you would like to change the number of columns that are in the tables that
hold the thumbnails or the gallery previews just change the $cols variable in
the corresponding PHP file.  

If you would like to make the thumbnails larger or smaller, change the
$maxthumbheight and $maxthumbwidth variables in index.php.  

Want better quality thumbnail previews? Change "imagecopyresized" to
"imagecopyresampled" in index.php.  Delete any "thumbs" directories you have
and go back to the gallery to generate the new higher quality thumbnails.  

Want the full size images to display in a pop-up instead of in their same
browser window?  
Comment out--
echo "<td class=\"sg\"><a class=\"sg\" href=\"$file\">";
And uncomment.
echo "<td class=\"sg\"><a
class=\"sg\"onclick=\"window.open(this.href,'_blank');return false;\"
href=\"$file\">"; 
in index.php. 

Hate the nothumbs.png image displaying when your galleries don't have
thumbnails? 
Comment out---
echo "<img class=\"sg\" src=\"nothumb.png\" alt=\"no thumbnail exists for
$file\" /><br />$file </a> </td>";
and 
echo "<td class=\"sg\"><a class=\"sg\" href=\"$file\">";
and Uncomment---
echo "<td class=\"sg\" ><a class=\"sg\" href=\"$file\">$file</a></td>";
in mainindex.php to display text links to the galleries instead.  
You of course also have the option of replacing the nothumbs.png with an image
you create or download.  

Want to see the names of the images on the gallery page and when you view the
image itself?  Search for "image name" in index.php and follow instructions
posted at those various places.   

If you do not want to use the gallery preview script (mainindex.php), you
don't have to.  Simply make the following change in index.php and then throw
it into your world-writable folders of jpegs. Link to these folders however
you see fit on your site/blog/whatever.
Change 
<h2 class="sg"><a class="sg" href="../">Galleries</a>:<?echo $galleryname;?>
<br /></h2>
to 
<h2 class="sg">Viewing:<?echo $galleryname;?> <br /></h2>
in index.php
You may also need to remove something similar from the javascript code blocks
if you choose to display the images with their names.


Notes
-------
-If you have any problems check/try the following:
 *Your web host must have PHP 4 and GD 2 (or higher).  
 *Folders full of images must be world-writable (chmod 777).
 *Any time you make a change to a gallery (rename a pic, delete a pic, add a
  pic---anything) it is a good idea to delete the "thumbs" directory inside of
  that folder. Next time you visit that gallery the thumbs will be re-built and
  will contain all the new changes.  
 *Corrupt images may cause problems. 
 *Images with weird characters in their names (. . /\*~`) may cause problems.
 *The first time you go to a gallery the thumbnails are built.  This can take a
  while. Be patient.  If the page completely fails to load this most likely
  means that the PHP script ran to long and was killed by your web hosts "max
  execution time" setting.  To solve this you can either try having less images
  in a folder or simply keep refreshing the page, it should pick up from where it
  left off the time before.  
-Things might not look perfect in Internet Explorer.  Luckily, everyone I care
 about uses firefox.  
-This is the only version of this script. I consider it a done project.  
-I guarantee nothing about this script. I am not offering any support for it,
so please do not contact me regarding it.      

Tips
------
-Try to name folders like this: 2008_disney_land_trip. 
This will allow the script to show a reasonable gallery name. 
-Try to name the images like this: view_from_hotel_room.jpg
This will allow the script to show a reasonable image name. 
Quick install using bash:
for X in `ls -d1 */`; 
do chmod 777 $X; cp -fv --reply=yes index.php $X; 
done;

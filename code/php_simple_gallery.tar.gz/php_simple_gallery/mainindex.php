<?
#This is the gallery preview script. 
#You don't have to use it.  

#You have two options...
#1) Drop the other file "index.php" into world writable folders full of JPEGs
#and then link to these folders full of images however you choose on your own
#page.  If you want to do this, you can delete this file.

#2) You can use this file to create links to all of your galleries. Here is how
#your folder structure will need to look if you are using Apache and you want
#to do this:
#/pics/nothumb.png
#/pics/mainindex.php
#/pics/index.php
#/pics/.htaccess
#/pics/2007 Beach Trip/index.php (copy this over to all your galleries).
#/pics/2006 Mountain Trip/index.php (copy this over to all your galleries).
#etc.
#Apache will use the .htaccess file in the /pics/ folder to make the webserver
#loads mainindex.php (this gallery preview script) in the photo-less /pics/
#directory instead of using the index.php file.

#If you are not using Apache and you want to use the gallery preview script,
#here is what your folder structure needs to look like: 
#/pics/nothumb.png 
#/pics/index.php 
# (index.php in this dir will be mainindex.php renamed to index.php). 
#/pics/2007 Beach Trip/index.php (original one copied over). 
#/pics/2006 Mountain Trip/index.php (original one copied over). 
#etc.  

#Basically, this file will get a list of all of the directories underneath it,
#create a table with links to these directories, and display a random thumbnail
#out of that gallery as the link to the gallery. In other words make 2007 Beach
#Trip/thumbs/RANDOM.jpg a link to the 2007 Beach Trip gallery. 

#Set where the script will pull its CSS definitions from.  If you want to use
#your master CSS file instead of sg.css, copy the definitions from sg.css to
#your file and then update the variable below to link to your css file instead.
#Note: You must change this in both PHP files.  
$cssfile = "sg.css";

#Start the page and the table
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<link rel="stylesheet" type="text/css" href="<?echo $cssfile;?>" />
<title>Simple Gallery:Galleries</title>
</head>
<body class="sg">
<h2 class="sg">Galleries<br /></h2>
<div class="sg">
<table class="sg">
<tr class="sg">
<?

#We will need to count up how many sub folders this directory has in it later
#in this script. To do that we will increase the variable dircount by 1 every
#time a directory is found.  But first we need to define dircount and start it
#counting at 0.  
$dircount = "0";

#When we build the table later in the script we will need to know how many
#columns we want it to have.  Lets define that here.  
$cols = "5";

#This script needs to know where to grab random thumbnails from.  The other
#script (index.php), that actually creates the thumbnails, uses the variable
#$thumbdir to create a a sub-folder in the gallery folder and then stores the
#thumbs in it.  The variable in this file needs to match what is in the
#other script. 
#It is also important to know that if you haven't been to the gallery yet it
#doesn't have thumbnails--so this file can't grab a random one.  Just go to the
#gallery, let it build the thumbs, then come back and refresh this 
#page.  
$thumbdir = "thumbs";

#Later in the script we will need to build an array out of the files in the
#thumbs folders so we can choose one at random.  Someone smarter than me
#wrote a function to do such things.  I will define it here and use it later.  

//Function to read directory contents into an array. 
//Taken from http://www.bigbold.com/snippets/posts/show/155
function directoryToArray($directory, $recursive) {
        $array_items = array();
        if ($handle = @opendir($directory)) {
                while (false !== ($file = readdir($handle))) {
                        if ($file != "." && $file != "..") {
                                if (is_dir($directory. "/" . $file)) {
                                        if($recursive) {
                                                $array_items = array_merge($array_items, directoryToArray($directory. "/" . $file, $recursive));
                                        }
                                        $file = $directory . "/" . $file;
                                        $array_items[] = preg_replace("/\/\//si", "/", $file);
                                } else {
                                        $file = $directory . "/" . $file;
                                        $array_items[] = preg_replace("/\/\//si", "/", $file);
                                }
                        }
                }
                closedir($handle);
        }
        return $array_items;
} 
//End Borrowed Code. 

#Now we need to open the directory we are in to do our work.   
#If we can open the directory we are in, continue.
if ($currentdir = opendir ("./"))
{
#Loop through everything in the directory
        while (false !== ($file = readdir($currentdir))) {

#If a directory is found (that isn't . this directory or .. a link to the
#directory above us) we need to do display a random thumbnail to it as a link
#in the table. Then we need to increase the dircount variable so we can keep
#count of exactly how many sub folders we are working with. 
if (is_dir($file) && $file!="." && $file!="..") {

#Now we need to see if the gallery folders in this directory have thumbnail
#sub-folders in them. In other words: Does /pics/2007 Beach Trip have a 
#"thumbs" folder in it.  Seeing if /pics/2007 Beach Trip/thumbs exists will
#let us know if the gallery has been visited yet and consequently if it has
#thumbnails yet or not. 
if (is_dir($file."/".$thumbdir)) {
#If this gallery folder does have thumbs we need to build an array out of the
#files in it and grab a random entry out of it.  

//Use the directoryToArray function to read the files in the "thumbs" directory
//into the thumbarray.
if ($thumbarray = directoryToArray($file."/".$thumbdir, false)) {

//The randomthumb variable gets a random value from the array. Here is how:
//RAND(om) starts its result set at 0 (lowest possible value) and ends at the
//highest number in the array by COUNT(ing) the results and subtracting 1.
$randomthumb = rand(0, count($thumbarray)-1);
#Start displaying the random thumbnail links in the table.    
#Start cell.  Link to the gallery directory.  
echo "<td class=\"sg\"><a class=\"sg\" href=\"$file\">";
#Show the random thumbnail. Make a text link. 
# End the link. End the cell.  Do it again. 
echo "<img class=\"sg\" src=\"$thumbarray[$randomthumb]\" alt=\"random thumbnail from $file\" /><br />$file </a> </td>";

}

}
else {
#If thumbnails don't exist for this gallery yet display the nothumb image.
#Start cell.  Link to the gallery directory. 
echo "<td class=\"sg\"><a class=\"sg\" href=\"$file\">";
#Show the nothumb image. Make a text link. End the link. End the cell.  
echo "<img class=\"sg\" src=\"nothumb.png\" alt=\"no thumbnail exists for $file\" /><br />$file </a> </td>";
#Don't like the no thumbnail image displaying until you visit a gallery?
#Comment out the 2 above echos and uncomment the one below to just show a text
#link to the gallery.  
#If thumbnails don't exist for this gallery yet.  Just display a text link.
#Start cell.  Link to the gallery directory. Close link. Close cell.
//echo "<td class=\"sg\" ><a class=\"sg\" href=\"$file\">$file</a></td>";
}

#Increase the known amount of sub-folders.  This is needed so we can build the
#table correctly.  
$dircount +=1;
#If the number of folders is now divisible by the number of columns you want
#in the table (without leaving a remainder) end the table row and start a new
#one. The final remainders will also be shown, the row just won't be full.  
if ( $dircount % $cols == 0 ) { echo "</tr><tr class=\"sg\">"; }
#End the processing of just folders.
}
#End the while. We've looked at all the files.  
}
#End the table and the page
#NOTE:
#We need to create one extra empty cell in order to meet XHTML spec.  If the
#number of table columns and the amount of images divide evenly there will be
#one extra row containing just one empty cell after all the even rows of
#images.  If the last row is not full of images (there should be at least one
#empty column) an additional empty cell will be added.  Note: We need to do
#this because XHTML spec does not allow empty table rows (<tr></tr>) and
#otherwise the even divides would create this situation.
echo "<td class=\"sg\"></td></tr></table></div></body></html>";
#If we couldn't open the directory complain. Note: This should never be
#displayed since this file is in the directory as well. 
#If you were unable to open the directory at all you would likely see a web
#server Forbidden message. 
}
else
{
echo
"<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\"
    \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">
<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"en\" lang=\"en\">
<head>
<link rel=\"stylesheet\" type=\"text/css\" href=\"$cssfile\" />
<title>Simple Gallery: Error </title>
</head>
<body class=\"sg\">
<h2 class=\"sg\"> Simple Gallery: Error </h2>
<p class=\"sg\">I was unable to open the directory that holds the galleries.  Permissions??</p>
</body>
</html>";
}
#Close directory
closedir ($currentdir);
?>

<?
//This file displays the news by reading it from the news.txt file.  Make sure
//news.txt is chmoded 766.  The CSS definitions determine how the news will
//look.  To hardcode variables look into the "table vars" in post.php.
//You don't have to use this file to display news on your page.  Simply copy
//the CSS definitions to your CSS file and use the <? include... line in your
//PHP file wherever you want the news to be displayed.
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
<style type="text/css">

table.sn {border-width: thin thin thin thin;
             border-spacing: 2px;
             border-color: gray gray gray gray;
             border-style: solid solid solid solid;
             border-collapse: collapse;
             text-align: center;
             empty-cells: show;
             background-color: white;
             margin-left: auto;
             margin-right: auto;
             width: 300px}

td.sn-title {font-family: sans-serif;
              border-width: thin thin thin thin;
              padding: 1px 1px 1px 1px;
              border-style: solid solid solid solid;
              border-color: gray gray gray gray;
              background-color: gray;
              color: black;
              font-size:14px;
              font-weight: bold}
td.sn-date {font-style: italic;
             font-family: sans-serif;
             border-width: thin thin thin thin;
             padding: 1px 1px 1px 1px;
             border-style: solid solid solid solid;
             border-color: gray gray gray gray;
             background-color: white;
             color: black;
             font-size:9px}
td.sn-post {font-family: monospace;
              border-width: thin thin thin thin;
              padding: 1px 1px 1px 1px;
              border-style: solid solid solid solid;
              border-color: gray gray gray gray;
              background-color: white;
              font-weight: bold;
              color: black;
              font-size:10px;}
</style>
<title>Simple News: Display</title>
</head>
<body>
<?
include("news.txt");
?>
</body>
</html>

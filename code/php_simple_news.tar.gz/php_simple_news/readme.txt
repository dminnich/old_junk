This is the super simple PHP News script.
-----------------------------------------
It allows you to add "news" to the top of a text file. This text file can be
integrated into your current site using "includes".  

Its features include:
-------------------------
-text file based.  no need for mysql. 
-very small and very simple.  the entire script is made up of 3 files. one
standard text file that stores the news.  one php file that displays this text
file, and one file that adds new entries to the news file.
-very easy to make it fit in with your site. This script is not intended to be
your site (like WP), instead it is meant to be a simple thing you can include
in a site you already have up and running.  the CSS definitions in display.php
define how your news will look when its displayed. The variables  in the
post.php file can be changed to hard coded values to affect how the table
looks in general. 
-very easy to change. this script uses very straightforward syntax and has
lots of comments.  If you have ever messed with PHP you should be able to
adapt it  to fit your needs.
-it outputs valid CSS and XHTML coding by default.
-completely free.  no links back to my page.  do whatever you like with this
script, i care not.

What this script doesn't do:
--------------------------------
 - No password protection.  Use htaccess files to protect post.php.
 - No archiving support.
 - No ability to preview posts.
 - No ability to edit or delete posts.
 - No multiple author support.
 - No pagination support.
 - No multiple user support.
 - No categories.
 - No comments.
 - No emoticons.
 - No WYSIWYG editor.  You are expected to know html.
 - No special Image or Video gallery or upload place.
 - No trackback, or any of that other BS.
 - No RSS feeds.
 - Not multilingual.
 - No deferred posts.
You might be wondering _just_ how this script would be useful to anyone at all
if it doesn't have any of those features. Below are the few cases in which I
think my script might be useful.
 - For people like me who want to put their opinions on the web occasionally,
   and honestly don't care about or want all those features.
 - Its useful for very basic news needs.  Sometimes programmers just want to
   write a quick blurb saying "new version of whatever released today". Or it
   could be used as status report page "the server will be undergoing 
   maintenance on 08/30".
 - For people new to PHP (like me).  This is a good script to look at and
   learn from and adapt to your needs.
 - For people who want something that is easy to integrate with the site they
   already have developed.

Standard Installation
----------------------
Upload all the files to your webhost. Your webhost must have PHP support.
CHMOD news.txt 766.
Use post.php to post news. Use display.php to view your posts.

More Secure Installation (DO THIS!)
------------------------------------
1) Create an "admin" directory on your webhost. 
2) update the post.php $newsfile variable so that it will be able to find the
news.txt file once you put it on your server.  If news.txt is one directory
below the admin directory it  should read $newsfile = "../news.txt";
3) Upload post.php into the admin folder. 
4) Then use your webhosts CP to password protect that directory.
5) Test the password protection.  Make sure you don't see the submission form
unless you enter the proper login and password. 
6) Upload news.txt and display.php to your webserver root directory.  
7) Chmod news.txt 766.  
8) Use /admin/post.php to add entries.  And /display.php to view them.

Customization
--------------
The best way to integrate this script with your page is like this.  Copy the
CSS definitions from display.php into your CSS file.  Then wherever in your
site you want to display the news you will simply put <? include("news.txt");
?>

If you want a separate page to display the news feel free to use the supplied
display.php.  

Basic colors, fonts, and spacing can all be changed in the display.php CSS
definitions.  They should be named obviously enough that you can figure them
out.  If you want to do more radical things you can update the "Table vars" in
post.php.  

Notes
-------
-This script has not been thoroughly tested.  And has not been tested at all
under Windows.
-This is the only version of this script. I consider it a done project. 
-I guarantee nothing about this script. I am not offering any support for it,
so please do not contact me regarding it. 

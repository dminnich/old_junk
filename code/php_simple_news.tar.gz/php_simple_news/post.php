<?
//File to keep news in.  If you are using the secure setup described in the
//readme with post.php in an .htaccessed admin dir you must update the location
//of news.txt file in the next variable.
$newsfile = "news.txt";
//Open news.txt in read mode.  
$file = fopen($newsfile, "r");
//Table Vars The below variables are inserted verbatim into the news.txt file.
//This gives you a lot of control over how the news will look.  The
//disadvantage is that if you ever decide you don't like how these look you
//can't change one thing like with CSS to adapt it to your liking.  You will
//have to do a mass "find and replace" on the news.txt file.  In other words:
//these are essentially the HTML tags that will go around your entries.  
//b=begin  e=end
$btable = "<table class='sn'> <tbody>";
$btitle = "<tr><td class='sn-title'>";
$etitle = "</td></tr>";
$bdate = "<tr><td class='sn-date'> Posted on:";
$edate = "</td></tr>";
$bpost = "<tr><td class='sn-post'>";
$epost = "</td></tr>";
$etable = "</tbody></table><div><br /></div>";
//Define PHP Date format.  Used for the default date form value.  
$defdate=date("m/d/Y");
//Other notes
//The date is automatically set to todays date by using PHP to echo the
//variable of defdate.  The form action uses this file itself to process the
//data.  
// The If/Else statements decide what is displayed based on whether a HTTP GET
// or POST was issued by the browser.  GET: If the submit button has not been
// pushed -- display form.  PUT: Submit button has been pushed -- write data to
// text file and display confirmation message.  
//IF browser does not send a POST request (ie: if submit has not been pressed)
//then display the form....
if ($_SERVER['REQUEST_METHOD'] != 'POST'){
//If able to open file do...
if ($file) {
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
<style type="text/css">
h2 {text-align: center}
</style>
<title>Simple News: Post</title>
</head>
<body>
<h2>Simple News: Post An Entry</h2>
<form action="<? echo $_SERVER['PHP_SELF']; ?>" method="post">
<div style="text-align: center">
Title: <input type="text" name="title" /> <br />
Date: <input type="text" name="date" value="<? echo $defdate; ?>" /> <br />
Entry:<br /> <textarea rows="30" cols="80" style="border: 1px solid #666666;" name="post"></textarea>
<br />
<input type="submit" value="Add News" />
</div>
</form>
</body>
</html>
<?
}
else 
//If can not open file complain...
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\"
     \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\"><html><head><title>Simple News: Error </title></head><body><p>Could not open file. <br /> Permissions??</p></body></html>";
}
//ELSE IF browser sends a POST request. Make sure that data was actually
//entered into the form and then write that data to the file....
elseif ((isset($_REQUEST["title"])) && (isset($_REQUEST["date"])) &&
(isset($_REQUEST["post"])) && ($_REQUEST["title"]!="") &&
($_REQUEST["date"]!="") && ($_REQUEST["post"]!="")) {
//The next few lines are a hacked up way to "add" text to the top of a file.
//// The file is already opened in read mode.  Read in all the current data
//from news.txt.  Save this as variable current_data.
$current_data = @fread($file, filesize($newsfile));
//Now that we have saved the old data to a variable lets close the file. 
fclose($file);
//Now we reopen the file in write mode.  This FIRST blanks the file.  Then will
//will write the new data followed by the old data to the file.  
$file = fopen($newsfile, "w");
//Write all of the table variables and the text entered into the form, plus the
//text that was already in news.txt to news.txt. The \n is a new line and it
//simply make news.txt more beautiful.  If it works display success message, if
//not display failure message. 

//// Fix quotes (') in entries and change any weird
//characters (&,<,>,etc) to their html equivalents.  Do the same for title and
//date. Even though it should not be needed for date.  
$_REQUEST["post"] = stripslashes(($_REQUEST["post"]));
$_REQUEST["date"] = stripslashes(($_REQUEST["date"]));
$_REQUEST["title"] = stripslashes(($_REQUEST["title"]));
if(fwrite($file,$btable . " " . $btitle . " " . $_REQUEST["title"] . " " .  $etitle . " " . $bdate . " " . $_REQUEST["date"] . " " . $edate . " " . $bpost . " " . $_REQUEST["post"] . " " . $epost . " " . $etable . "\n " . $current_data))
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\"
    \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\"><html><head><title>Simple News: Entry Added</title></head><body><p>Entry added successfully.<br /> <a href=\"\">Add</a> another.</p></body></html>";
else 
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\"
     \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\"><html><head><title>Simple News: Entry NOT Added!</title></head><body><p>Could not add entry.<br /> Permissions??</p></body></html>";
//Close the file.  
fclose($file);
}
//If the browser sent a POST request but the user failed to put data in the
//form...spit out this error.   
else
echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\"
     \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\"><html><head><title>Simple News: Entry NOT Added!</title></head><body><p>Could not add entry. <br /> All the fields in the form are *required*. <br /> Please go back and try again.</p></body></html>";
?>

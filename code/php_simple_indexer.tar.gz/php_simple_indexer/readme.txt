This is a simple PHP Directory Indexing script.
-----------------------------------------------
It displays the contents of folders (and their subfolders if the option is
set) in an CSS customizable table. Each file can have its own description, and
certain files can be excluded from the index.    

Features:
-------------
-Can display the contents of just the folder it is in or the contents of all
folders underneath it as well.
-Files can be excluded from the index.
-Easy to install.  Just drop it into the folder you want it to index.
-The _description.txt file allows every file to have its own description.
-Very small.  The entire script is one file.
-Text file based.  MySQL not needed.  
-Very easy to change. this script uses very straightforward syntax and has
lots of comments.  If you have ever messed with PHP you should be able to
adapt it to fit your needs.
-CSS customizable.  
-Outputs full page valid XHTML and CSS. 
-completely free.  no links back to my page.  do whatever you like with this
script, i care not.

What this script doesn't do:
-------------------------------
-Show any advanced file statistics.  What you will get is a link to the
filename and an optional description.  You WONT get the size of the file, when
it was modified, who owns it, its type, any pretty icons, etc.  
-Allow you to upload,edit,chmod,chown,delete,etc files. This is not a file
manager, it is a directory indexer.  
-Anything special with media.  It does not create image thumbnails or do a
gallery, it does not have some fancy movie player or anything of the like, all
it does is make text links to your files.  
-Click tracking.  This does not count how many times a file was download or
keep any statistics related to this matter. 
-Prevent hot linking in any way.
-Automatically generate "pages" for each file when they are clicked. 

Who this script is for:
----------------------------
-Me!
-People that want recursive directory listings on one page. 
-People who want something more customizable than apaches directory listing.
Or people who don't have the rights to  modify the style of apaces directory
listing.   
-People who want to exclude lots of files from a directory listing. 
-People who want to have descriptions along with some filenames in their
directory listings. 
-People that don't need an advanced download system or even need to tell their
vistors much about the files they are offering to download.
-People who have what I call "dump" dirs.  
-People who do not have access to a mysql server.
-For people new to PHP (like me).  This is a good script to look at and learn
from and adapt to your needs.

Installation
--------------
1) Drop index.php into the folder that you want to have an index. 
2) Make sure that the folder it is in and any subfolders you want it to index
are chmoded at least 555.  Also make sure _description.txt is chmoded at
least 444 if you plan to use it.  
3) Go to that folder on your site and test it out. 

If you want a recursive listing:
1) Open index.php.
1) Comment out the recurse == 'NO' line.  In other words add "//" in front of
   it.  
2) Uncomment the recurse == 'YES' line. Delete the "//" from in front of it. 
3) Save your changes.  

If you want to exclude a file from a listing:
1) Open index.php
2) Find the exclude[x] lines.  Copy the bottom one. Insert a new line below it
   (hit enter).  Paste the line you copied.  
3) Increase [x] by one.  
4) Change the text inside the quotes to the filename you want to hide.
   Case must match exactly.  
5) Save your changes. 
NOTE: You can exclude folders as well.  Just list their names without a
trailing slash. If you hide a directory all files and folders underneath 
it will be hidden as well. 
NOTE: By default the up directory links, the index.php file, the 
_description.txt file, and all unix dot "." files are hidden. 
LIMITATIONS/EXCLUDING THINGS IN FOLDERS:  Things are excluded on a "filename"
basis, not a "path/filename" basis. If you wanted to hide /work/resume.doc
you would add a line like this: $exclude[2] = "resume.doc";. However this
means that school/english111/papers/resume.doc and /resume.doc would also be
hidden.  This same thing applies to folders as well.  Also filenames and
folders will both be blocked if one is blocked (ie: excluding "todo" will
block todo/ and todo).Basically this means if you want to do anything
complicated you need all uniquely named folders and files.  For small sites
this should not be a problem. 

If you want file descriptions:
1) Add the descriptions you want to _description.txt file. Here is the
   syntax:
   filename|description
   For example:
   tyra_banks.jpg|Hot chick. 
   oprah.jpg|A modern day anti-christ.  
   The case of the filename must be the *exact* same as the case of the file
   on the server. In other words Oprah.jpg wouldn't work if the file itself
   is oprah.jpg.  Each description should be seperated by a new line (an
   enter).  Make sure you use unix line breaks, windows may or may not work. 
   Do NOT use any special characters in your descriptions. NO " ' : ; | { } <
   > @ # $ % ^ & * ( ) etc.  
2) Upload the _description.txt file into the same directory that index.php is
   in.  
3) Chmod it to at least 444.
NOTE: You can add descriptions to folders as well.  Just add their names to
the _description.txt file without a trailing slash.
LIMITATIONS/DESCRIBING THINGS IN FOLDERS:  Things are described on a
"filename"  basis, not a "path/filename" basis.  Meaning to describe the file
documents/resume.doc you would add a line like this: “resume.doc|my resume” to
_description.txt .  However this means that
school/english111/papers/resume.doc and /resume.doc would also have the same
description.  The same thing applies to folders as well.  Also filenames and
folders will both be described as the same if one is described (ie: describing
"todo" will describe todo/ and todo).Basically this means if you want to do
anything complicated you need all uniquely named folders and files.  For small
sites this should not be a problem.  



Customization
--------------
Update the CSS definitions inside of index.php.  The table, tr, and each td,
as well as the body of the document has CSS definitions.  Just open index.php
search for //CSS Definitions.  Change whatever you like there. 

Want to use an external CSS file you have somewhere?
Open index.php.  Search for //CSS Definitions.  Copy all of the definitions to
your CSS file.  Search for //External CSS.  Set use_external_css to YES
instead of NO.  Change the external_css_file variable so that it points to
your CSS file. Try to keep the external_css_file out of the directory that
is being indexed so it won't show up.  


If you want to make bigger changes search for //BEGIN HTML in index.php. Hack
away at all of the HTML tags that soon follow.  


Notes
-------
-If you are using recursive mode register globals must be ON.  
-If you want the "Index of" titles to work properly link to
 /your_dir/index.php.
-If you use recursive mode you may notice that everything is 
 in exact (path based) alphabetical order. Meaning files may
 not be broken up in the exact same way an that an 
 Operating system would break them up. This is
 because the recursive directory to array function I use 
 gets all the files in a path into an array in one big call.
 Then they are all sorted.  If anybody has a code snippet
 that would call each subdirectory into its own array that 
 could be sorted and then later merged into a master array
 let me know.  I'm not smart enough to code such a monster. 
-If you have any problems make sure that the directories you want to index
 are chmoded at least 555, and the _description.txt is chmoded at least 
 444. Make sure that the filenames in _description.txt match the files case
 exactly, make sure you don't use any weird characters in descriptions, and
 make sure that _description.txt uses unix line breaks.
-Props to: 
    Ivo van Sandick.  <--- array combine script
    XoloX http://www.bigbold.com/snippets/posts/show/155 
     ^--Recursive directory to array script.
-This script has not been thoroughly tested.  And has not been tested at all
 under Windows.
-This is the only version of this script. I consider it a done project. 
-I guarantee nothing about this script. I am not offering any support for it,
 so please do not contact me regarding it.

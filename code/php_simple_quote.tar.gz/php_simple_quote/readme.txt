This is a simple PHP Random Quote script.
-----------------------------------------
Displays a random quote out of a text file full of quotes.

Features:
-------------
-Very small.  The entire script is one file.  
-Text file based.  MySQL not needed.  
-Very easy to change. this script uses very straightforward syntax and has
lots of comments.  If you have ever messed with PHP you should be able to
adapt it to fit your needs.
-CSS customizable.  
-Easy to integrate into your current page. 
-completely free.  no links back to my page.  do whatever you like with this
script, i care not.

What this script doesn't do:
-------------------------------
-Allow you to add/edit/delete quotes from a web based manager. 
-No complicated randomizer / pseudo-generator is used in order to get "random"
results. 
-Does not output full page valid XHTML and CSS.  This is intentional, so you
can easily include the quotes in your current pages. 

Who this script is for:
----------------------------
-Me! 
 -People who want a small random quote script that is easy to integrate
into their current site.  
-People who do not have access to a mysql server.
-For people new to PHP (like me).  This is a good script to look at and learn
from and adapt to your needs.

Installation
--------------
1) Update the quotesfile  variable in quote.php.  -- This is only necessary if
you plan on using a different file from quotes.txt.  Or if you plan on putting
quotes.txt in a folder other than the directory this script is in.  If you do
wish to change it use a path and filename relative to where this script is.--
2) Add some quotes to quotes.txt.  Each quote should be separated by a new
line. 
3) Upload quote.php and quotes.txt to your webhost. 
4) Make sure quotes.txt is world readable.  CHMOD it at least 444.
5) Test the script by going to yoursite/quote.php. 
6) Include the quotes on your main pages. 
Do <? include ("quote.php"); ?> Wherever you want the quotes to appear.  This
assumes that quote.php is in the same folder as your main page.  

Customization
--------------
Create a p.quote CSS definition in the file that includes quote.php.  This
will allow you to change font color, size, face, and other things.  

Change the starting HTML tags and closing HTML tags in quote.php to make hard
coded changes to how the quote appears.  


Notes
-------
-If you have any problems make sure that quotes.txt is world readable (chmoded
444), make sure the quotesfile variable points to a valid file, and   make
sure that quotes.txt uses unix line breaks (windows may or may not work).
-This script has not been thoroughly tested.  And has not been tested at all
under Windows.
-This is the only version of this script. I consider it a done project. 
-I guarantee nothing about this script. I am not offering any support for it,
so please do not contact me regarding it.


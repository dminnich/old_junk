<?
//Relative path to and the filename of the file that contains your quotes. Each
//quote should be separated by a NEW LINE.  The default is to use the file
//quotes.txt that is located in the same directory as this file. 
$quotesfile = "quotes.txt";
//You should not have to edit anything after this line.  

//Copy quotes from the text file into the array.  Don't display an error if the
//text file can not be opened.  This is to avoid ugliness in case you already
//have this PHP file included on your front page and something goes crazy.  
if ($array = @file("$quotesfile")) {  
//If the file was opened and the array was built successfully define the quote
//variable.  The quote variable gets a random value from the array. Here is
//how:  RAND(om) starts its result set at 0 (lowest possible value) and ends at
//the highest number in the array by COUNT(ing) the results and subtracting 1.  
$quote = rand(0, count($array)-1);
//Echo the starting HTML tags for the quote. Add a p.quote CSS definition to
//the file that includes this one to customize how the quote looks.
echo "<p class=\"quote\">";
//Covert weird characters to html entities. 
$array[$quote] = stripslashes(htmlentities($array[$quote])); 
//Echo a random quote from the array.  
   echo $array[$quote];
//Echo the closing HTML tags for the quote.  
   echo "</p>";
//If quotes file can not be found or opened say so.
}  
else{
   echo ("<p class=\"quote\">Quotes file not found or can not be opened.</p>");  
}
?> 

#! /usr/bin/env python
#This and the other ugly linux2ad scripts plus my Linux and Windows AD interoperability guide will help you convert from NIS or /etc/passwd setups to a setup where your Linux machines get all of their user and group info from a Windows 2008 AD setup.  These users will also be able to authenticate on the linux machine using their AD passwords.  

#First you need to grab a copy of your /etc/passwd and /etc/group files or a dump of NIS and clean it up.  You just want "real" accounts and groups in the AD.  Removing everything below IDs 500 should work in most environments.  

#Anyhow, follow the directions in the scripts to do your mass "database" migration. 

#run this 3rd! it adds the users you already created to empty groups you've already created.  

#your domain
domain = "dc=org,dc=domain,dc=local"
#nis domain. not really sure what Windows uses it for but its usually the 
#short part of your domain
nis = "org"
#domain suffix.  like you would be emailing to it
domainsuffix = "org.domain.local"
#Most linux distros automatically create an account and a group for a user.  Both of these objects are named the exact same thing. 
#It is not possible to have 2 objects named the same thing in the AD.  For this reason, you must either make sure that none of your
#single user groups exist in your cleaned up group file, or we can prefix all the groups we create with something. I chose this route
#because it has the added benefit of making the groups pop out at you in the Users OU in AD users and computers since things are mixed
#in there anyhow.  
gprefix = "g-"




#create a dictionary for storing name and gecos
dict = {}
#open the cleaned up passwd file.  will need this for gecos.
e = open('passwd', 'r')
for line in e:
#line minus the newline carriage return character
        line = line[:-1]
#split the line by : naming the fields
        name, passwd, uid, gid, gecos, home, shell = line.split(":")
        dict[name] = gecos
e.close()



#open your cleaned up group file
f = open('group', 'r')
for line in f:
#line minus the newline carriage return character
	line = line[:-1]
#split the line by : naming the fields
	gname, gpasswd, gid, users = line.split(":")
#create an info list storing two of those variables
	info = [gname, gid]
#create a list using each username as an item split where there is commas
	userslist = users.split(',')
#create an ldif file for each group
	out = open(info[0] + ".ldif", 'a')
#needed ldif schema bits
	out.write("dn: CN=" + gprefix + info[0] +  ",CN=Users," + domain + "\n")
	out.write("changetype: modify" + "\n")
	for user in userslist:
#loop through the userlist list and make a member line for each person in it.
		out.write("member: CN=" + dict[user] + ",CN=Users," + domain + "\n")
		out.write("msSFU30PosixMember: CN=" + dict[user] + ",CN=Users," + domain + "\n")
		out.write("memberUid: " + user + "\n")
	out.close()
	
f.close()


#BASH MASS ADD THE CREATED LDIFS
#for x in *ldif;
#do
#ldapmodify -x -H ldap://PDC -D "Administrator@domain" -f ${x} -w yourpassword
#done
#remove all the ldif files once the insert completes successfully
#rm -f *ldif 

#! /usr/bin/env python
#This and the other ugly linux2ad scripts plus my Linux and Windows AD interoperability guide will help you convert from NIS or /etc/passwd setups to a setup where your Linux machines get all of their user and group info from a Windows 2008 AD setup.  These users will also be able to authenticate on the linux machine using their AD passwords.  

#First you need to grab a copy of your /etc/passwd and /etc/group files or a dump of NIS and clean it up.  You just want "real" accounts and groups in the AD.  Removing everything below IDs 500 should work in most environments.  

#Anyhow, follow the directions in the scripts to do your mass "database" migration. 

#run this script 2nd! it creates the user accounts 

#your domain
domain = "dc=org,dc=domain,dc=local"
#nis domain. not really sure what Windows uses it for but its usually the 
#short part of your domain
nis = "org"
#domain suffix.  like you would be emailing to it
domainsuffix = "org.domain.local"


f = open('passwd', 'r')
for line in f:
#line minus the newline carriage return character
        line = line[:-1]
#split the line by : naming the fields
        name, passwd, uid, gid, gecos, home, shell = line.split(":")
#create an info list storing those variables
        info = [name, uid, gid, gecos, home, shell]
#create a list using each gecos item split where there is a space
#this makes First and Last names look right if you used unix gecos for such things.
        names = gecos.split(' ')
#create an ldif file for each group
        out = open(info[0] + ".ldif", 'a')
#needed ldif schema bits
        out.write("dn: CN=" + info[3] + ",cn=Users," + domain + "\n")
        out.write("changetype: add" + "\n")
        out.write("objectClass: top" + "\n")
        out.write("objectClass: person" + "\n")
        out.write("objectClass: organizationalPerson" + "\n")
        out.write("objectClass: user" + "\n")
        out.write("cn: " + info[3] + "\n")
        out.write("sn: " + names[1] + "\n")
        out.write("givenName: " + names[0] + "\n")
        out.write("distinguishedName: CN=" + info[3] + ",cn=Users," + domain + "\n")
        out.write("instanceType: 4" + "\n")
        out.write("userAccountControl: 514" + "\n")
        out.write("accountExpires: 0" + "\n")
        out.write("displayName: " + info[3] + "\n")
        out.write("name: " + info[3] + "\n")
        out.write("codePage: 0" + "\n")
        out.write("countryCode: 0" + "\n")
        out.write("sAMAccountName: " + info[0] + "\n")
        out.write("userPrincipalName: " + info[0] +  "@" + domainsuffix + "\n")
        out.write("objectCategory: CN=Person,CN=Schema,CN=Configuration," + domain +  "\n")
        out.write("uid: " + info[0] + "\n")
        out.write("msSFU30Name: " + info[0] + "\n")
        out.write("msSFU30NisDomain: " + nis +  "\n")
        out.write("uidNumber: " + info[1] + "\n")
        out.write("gidNumber: " + info[2] + "\n")
        out.write("unixHomeDirectory: " + info[4] + "\n")
        out.write("loginShell: " + info[5] + "\n")
f.close()


#BASH MASS ADD THE CREATED LDIFS
#for x in *ldif;
#do
#ldapmodify -x -H ldap://PDC -D "Administrator@domain" -f ${x} -w yourpassword
#done
#remove all the ldif files once the insert completes successfully
#rm -f *ldif
